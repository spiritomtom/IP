package com.example.SurveyApp;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.UUID;

@Controller
public class MyController {

    public static void databaseConnection() throws SQLException {
        String jdbcURL = "jdbc:mysql://localhost:3306/surveys";
        String username = "root";
        String password = "pepi1234";

        Connection connection = DriverManager.getConnection(jdbcURL,username,password);

        //language=MySQL
        String sql = "SELECT * FROM test";
    }

    @GetMapping("/**")
    public String home(){
        return "index.html";
    }

    @GetMapping("/createSurvey")
    public String createSurvey(Model model){
        Survey survey = new Survey();
        model.addAttribute("survey",survey);
        return "create_survey";
    }


    @PostMapping("/createSurvey")
    public String submit(@ModelAttribute("survey") Survey survey) throws SQLException {

        String jdbcURL = "jdbc:mysql://localhost:3306/surveys";
        String username = "root";
        String password = "pepi1234";

        Connection connection = DriverManager.getConnection(jdbcURL,username,password);
        String query = "insert into questions(questionId, question) VALUES (?,?)";
        PreparedStatement preparedStmt = connection.prepareStatement(query);
        preparedStmt.setString(1, survey.getId());
        preparedStmt.setString(2, survey.getQuestion());
        preparedStmt.execute();
        for (String answer :survey.getAnswers()
             ) {
            String  answerID = UUID.randomUUID().toString();
            int count = 0;


            String query2 = " insert into answers (answerId, answer_text,questionID,answeredCount)"
                    + " values (? , ?,?,?)";

            // create the mysql insert preparedstatement
            PreparedStatement preparedStmt2 = connection.prepareStatement(query2);
            preparedStmt2.setString(1, answerID);
            preparedStmt2.setString(2, answer);
            preparedStmt2.setString(3, survey.getId());
            preparedStmt2.setInt(4,0);

            // execute the preparedstatement
            preparedStmt2.execute();


            count++;
        }
        connection.close();
        return "links";
    }

    @GetMapping("/result/{questionId}")
    public String getResult(@PathVariable String questionId, Model model) throws SQLException {
        String jdbcURL = "jdbc:mysql://localhost:3306/surveys";
        String username = "root";
        String password = "pepi1234";

        Connection connection = DriverManager.getConnection(jdbcURL,username,password);

        String query = "select * from answers where questionID = ?";

        ArrayList<String> answerTexts = new ArrayList<String>();
        ArrayList<String> counts = new ArrayList<String>();

        PreparedStatement preparedStmt = connection.prepareStatement(query);
        preparedStmt.setString(1, questionId);

        try {
            ResultSet resultSet = preparedStmt.executeQuery();

            while (resultSet.next()) {
                answerTexts.add(resultSet.getString(2));
                counts.add(resultSet.getString(4));

            }


        } finally {
            preparedStmt.close();

            model.addAttribute("answerTexts",answerTexts);
            model.addAttribute("counts",counts);
        }
        String queryQuestion = "select * from questions where questionId = ?";

        PreparedStatement preparedStatement2 = connection.prepareStatement(queryQuestion);
        preparedStatement2.setString(1,questionId);
        String var = "";
        try {

            ResultSet resultSet2 = preparedStatement2.executeQuery();
            while (resultSet2.next()) {
                 var = resultSet2.getString(2);
            }
        }finally {
            preparedStatement2.close();
            model.addAttribute("question", var);

        }


        connection.close();
        return "results";
    }
    @GetMapping("/vote/{questionId}")
    public String getForm(@PathVariable String questionId, Model model) throws SQLException {
        String jdbcURL = "jdbc:mysql://localhost:3306/surveys";
        String username = "root";
        String password = "pepi1234";

        Connection connection = DriverManager.getConnection(jdbcURL,username,password);
        ArrayList<String> answerTexts = new ArrayList<String>();
        String query = "select * from answers where questionID = ?";
        ArrayList<String> answerIds = new ArrayList<String>();

        String query2 = "select * from questions where questionId=?";
        Survey current_survey = new Survey();
        PreparedStatement preparedStmt = connection.prepareStatement(query);
        preparedStmt.setString(1, questionId);

        try {
            ResultSet resultSet = preparedStmt.executeQuery();

            while (resultSet.next()) {
                answerTexts.add(resultSet.getString(2));
                answerIds.add(resultSet.getString(1));
            }


        } finally {
            preparedStmt.close();

           model.addAttribute("answers", answerTexts);
           model.addAttribute("answersIds", answerIds);
        }
        String queryQuestion = "select * from questions where questionId = ?";

        PreparedStatement preparedStatement2 = connection.prepareStatement(queryQuestion);
        preparedStatement2.setString(1,questionId);
        String var = "";
        try {

            ResultSet resultSet2 = preparedStatement2.executeQuery();
            while (resultSet2.next()) {
                var = resultSet2.getString(2);
            }
        }finally {
            preparedStatement2.close();
            model.addAttribute("question", var);

        }



        return "vote";
    }

    @PostMapping("/vote")
    public String updateAnswerCount(@RequestParam(value = "answerID", required = true) String answerID) throws SQLException {
        String jdbcURL = "jdbc:mysql://localhost:3306/surveys";
        String username = "root";
        String password = "pepi1234";

        Connection connection = DriverManager.getConnection(jdbcURL,username,password);
        System.out.println(answerID);
        String query = "UPDATE answers SET answeredCount = answeredCount+1 where answerId=?";
        PreparedStatement preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1,answerID);

        preparedStatement.execute();
        preparedStatement.close();
        connection.close();

       return "index";
    }

}

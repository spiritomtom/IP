package com.example.SurveyApp;

import java.util.ArrayList;
import java.util.UUID;

public class Survey {
    private String id = UUID.randomUUID().toString();
    public String question;
    public ArrayList<String> answers;
    public int answeredCount=0;

    public int getAnsweredCount() {
        return answeredCount;
    }

    public void setAnsweredCount(int answeredCount) {
        this.answeredCount = answeredCount;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public ArrayList<String> getAnswers() {
        return answers;
    }

    public void setAnswers(ArrayList<String> answers) {
        this.answers = answers;
    }

    @Override
    public String toString() {
        return "Survey{" +
                "id='" + id + '\'' +
                ", question='" + question + '\'' +
                ", answers=" + answers +
                ", answeredCount=" + answeredCount +
                '}';
    }

}
